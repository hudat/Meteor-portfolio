(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['chrismbeckett:fontawesome4'] = {};

})();

//# sourceMappingURL=chrismbeckett_fontawesome4.js.map
