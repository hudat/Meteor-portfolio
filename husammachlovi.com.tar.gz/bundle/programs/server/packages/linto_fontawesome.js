(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['linto:fontawesome'] = {};

})();

//# sourceMappingURL=linto_fontawesome.js.map
